#include "function.h"



void init(int *mass)
{
	for (int i = 0; i < size; i++)
		mass[i] = rand()%20;
}
void init(double *mass)
{
	for (int i = 0; i < size; i++)
		mass[i] = rand() % 20 * 0.03;
}
void init(char *mass)
{
	for (int i = 0; i < size; i++)
		mass[i] = (char)rand() % 256;
}




void print(int *mass)
{
	for (int i = 0; i < size; i++)
		cout << mass[i] << " ";
}
void print(double *mass)
{
	for (int i = 0; i < size; i++)
		cout << mass[i] << " ";
}
void print(char *mass)
{
	for (int i = 0; i < size; i++)
		cout << mass[i] << " ";
}




void min(int *mass)
{

}
void min(double *mass)
{

}
void min(char *mass)
{

}




void max(int *mass);
void max(double *mass);
void max(char *mass);




void sort(int *mass);
void sort(double *mass);
void sort(char *mass);




void change(int *mass);
void change(double *mass);
void change(char *mass);