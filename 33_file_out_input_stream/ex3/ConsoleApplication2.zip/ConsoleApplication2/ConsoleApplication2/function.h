#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include <ctime>
using namespace std;

const int size = 10;

void init(int *mass);
void init(double *mass);
void init(char *mass);

void print(int *mass);
void print(double *mass);
void print(char *mass);

void min(int *mass);
void min(double *mass);
void min(char *mass);

void max(int *mass);
void max(double *mass);
void max(char *mass);

void sort(int *mass);
void sort(double *mass);
void sort(char *mass);

void change(int *mass);
void change(double *mass);
void change(char *mass);